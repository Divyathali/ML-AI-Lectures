#ifndef __DEFINES_H_
#define __DEFINES_H_

#define BMP_HEADER_SIZE 54

#define COLS 720

#endif
